function detaily(argument) {
    $(".btn").click(function() {
        $(this).next().toggleClass('hidden');
    });
    // body...
}


//Funkcia pre kliku na element listu preciarkne ulohu
